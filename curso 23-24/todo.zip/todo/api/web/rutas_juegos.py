from flask import request, make_response, escape
import json
import decimal
from __main__ import app
from funciones import prepare_response_extra_headers,validar_session_normal,validar_session_admin
import controlador_juegos

class Encoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, decimal.Decimal): return float(obj)

response_extra_headers = prepare_response_extra_headers(True)

@app.route("/juegos",methods=["GET"])
def juegos():
    if (validar_session_normal()):
        ret,code= controlador_juegos.obtener_juegos()
    else:
        ret={"status":"Forbidden"}
        code=403
    response=make_response(json.dumps(ret, cls = Encoder),code)
    return response

@app.route("/juego/<id>",methods=["GET"])
def juego_por_id(id):
    if (validar_session_normal()):
        ret,code = controlador_juegos.obtener_juego_por_id(id)
    else:
        ret={"status":"Forbidden"}
        code=403
    response=make_response(json.dumps(ret, cls = Encoder),code)
    return response

@app.route("/juegos",methods=["POST"])
def guardar_juego():
    if (validar_session_admin()):
        code = 200
        content_type = request.headers.get('Content-Type')
        if (content_type == 'application/json'):
            juego_json = request.json
            nombre = juego_json["nombre"].strip().replace('"',"")
            nombre = f"{escape(nombre)}";
            descripcion = juego_json["descripcion"].strip()
            precio = juego_json["precio"].strip()
            foto = juego_json["foto"].strip()
            if (len(nombre) ==0 or len(nombre) > 256):
                ret={"status":"Bad request n"}
                code=401 
            if (code == 200 and len(descripcion) > 256):
                ret={"status":"Bad request d"}
                code=401 
            if (code == 200 and len(foto) > 256):
                ret={"status":"Bad request f"}
                code=401
            if (code == 200 and not precio.replace(".", "").isdecimal()):
                ret={"status":"Bad request p"}
                code=401
            if (code == 200):
                try:
                    precio = float(precio)
                except:
                    ret={"status":"Bad request pf"}
                    code=401 
            if (code == 200):
                ret,code=controlador_juegos.insertar_juego(nombre,descripcion,precio,foto)
        else:
            ret={"status":"Bad request"}
            code=401
    else:
        ret={"status":"Forbidden"}
        code=403
    
    response=make_response(json.dumps(ret),code)
    return response

@app.route("/juegos/<id>", methods=["DELETE"])
def eliminar_juego(id):
    if (validar_session_admin()):
        ret,code=controlador_juegos.eliminar_juego(id)
    else:
        ret={"status":"Forbidden"}
        code=403
    
    response=make_response(json.dumps(ret),code)
    return response

@app.route("/juegos", methods=["PUT"])
def actualizar_juego():
    if (validar_session_admin()):
        content_type = request.headers.get('Content-Type')
        if (content_type == 'application/json'):
            juego_json = request.json
            ret,code=controlador_juegos.actualizar_juego(juego_json["id"],juego_json["nombre"], juego_json["descripcion"], float(juego_json["precio"]),juego_json["foto"])
        else:
            ret={"status":"Bad request"}
            code=401
    else:
        ret={"status":"Forbidden"}
        code=403

    response=make_response(json.dumps(ret),code)
    return response